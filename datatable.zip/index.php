<?php  
$con=mysqli_connect("localhost","root","","student_id");
if(isset($_POST['form'])){
    $sname=$_POST['sname'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $number=$_POST['number'];
    $date=$_POST['date'];
    $password=$_POST['password'];
    $c_pass=$_POST['c_pass'];
    $query=mysqli_query($con,"INSERT INTO `form`( `sname`, `username`, `email`, `number`, `date`, `password`, `c_pass`) VALUES ('$sname','$username','$email','$number','$date','$password','$c_pass')");
    if(isset($query)){
        echo "<script>
        alert('Successfully your infomation submit');
        window.location.href='admin.php';
        </script>";
    }else{
        echo "<script>
        alert('some error please try again!');
        window.location.href='index.php
     </br>';
        </script>";
    }

}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>form</title>
</head>
<body>
    <form action="#" method="POST" >
        <div class="form_itams">
            <input type="text" name="sname" placeholder="name"  >
        </div>
     </br>
        <div class="form_itams">
            <input type="text" name="username" placeholder="username"  >
        </div>
     </br>
        <div class="form_itams">
            <input type="email" name="email" placeholder="email"  >
        </div>
     </br>
        <div class="form_itams">
            <input type="number" name="number" placeholder="number"  >
        </div>
     </br>
        <div class="form_itams">
            <input type="date" name="date" >
        </div>
     </br>
        <div class="form_itams">
            <input type="password" name="password" placeholder="password"  >
        </div>
     </br>
        <div class="form_itams">
            <input type="password" name="c_pass" placeholder="confirm password"  >
        </div>
     </br>
        <div class="form_button">
            <input type="submit" name="form" value="submit">
        </div>
    </form>
    
</body>
</html>