<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/dataTables.dataTables.css" />
  
  

</head>
<body>
  
<table id="myTable" class="display">
    <thead>
        <tr>
            <th>Id</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Mobile</th>
        
        </tr>
    </thead>
    <tbody>
      <?php 
      $con=mysqli_connect("localhost","root","","order");
        $data_select=mysqli_query($con,"SELECT * FROM `orders`");
            while($rows=mysqli_fetch_assoc($data_select)){?>
                <tr>
                    <td><?=$rows['id']?></td>
                    <td><?=$rows['name']?></td>
                    <td><?=$rows['email']?></td>
                    <td><?=$rows['phone']?></td>
                   
                </tr>

<?php

            }
      ?>
      
    </tbody>
</table>
<br>
<br>
<table id="myTableReport" class="display">
    <thead>
        <tr>
            <th>Id</th>
            <th>Student Name</th>
            <th>Email</th>
            <th>Mobile</th>
        
        </tr>
    </thead>
    <tbody>
      <?php 
      $con=mysqli_connect("localhost","root","","order");
        $data_select=mysqli_query($con,"SELECT * FROM `orders`");
            while($rows=mysqli_fetch_assoc($data_select)){?>
                <tr>
                    <td><?=$rows['id']?></td>
                    <td><?=$rows['name']?></td>
                    <td><?=$rows['email']?></td>
                    <td><?=$rows['phone']?></td>
                   
                </tr>

<?php

            }
      ?>
      
    </tbody>
</table>

<script src="./js/jquery-3.7.1.js" ></script>
<script src="./js/dataTables.js" ></script>
<script src="./js/dataTables.buttons.js" ></script> 
<script src="./js/buttons.dataTables.js" ></script>
<script src="./js/jszip.min.js" ></script>
<script src="./js/pdfmake.min.js" ></script>
<script src="./js/vfs_fonts.js" ></script>
<script src="./js/buttons.html5.min.js" ></script>
<script src="./js/buttons.print.min.js" ></script>


<script>

$(document).ready( function () {
    $('#myTable').DataTable();
} );
$(document).ready( function () {
    new DataTable('#myTableReport', {
    layout: {
        topStart: {
            buttons: ['copy', 'csv', 'excel', 'pdf', 'print']
        }
    }
});
} );
</script>
</body>
</html>